# set module constants
eps_ice_x = complex(3.16835, 0.0089)
eps_liq_x = complex(44.593, 41.449)
wavl_x = 32.1
kw2 = 0.93
